result wil be save here
