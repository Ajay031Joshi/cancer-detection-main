Dataset download link: https://challenge.kitware.com/#phase/5abcb19a56357d0139260e53

Download training dataset and ground truth data and extract both of them in this folder